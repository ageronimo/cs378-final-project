# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "".split(';') if "" != "" else []
PROJECT_CATKIN_DEPENDS = "cv_bridge;image_transport;opencv3;roscpp".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "".split(';') if "" != "" else []
PROJECT_NAME = "color_tracking"
PROJECT_SPACE_DIR = "/home/nvidia/catkin_ws/src/devel"
PROJECT_VERSION = "0.0.0"
